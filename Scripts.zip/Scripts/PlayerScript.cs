using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class PlayerScript : MonoBehaviour
{
    public GameObject[] enemyList;
    public Transform target;
    public bool enemyRange;
    public float radius;
    [Range(0, 360)]
    public float angle;

    EnemyScript health;
    PlayerMovement playerHealth;




    public LayerMask targetMask;
    public LayerMask obstructionMask;

    void Start()
    {
        
        playerHealth = GetComponent<PlayerMovement>();
        StartCoroutine(FOVRoutine());

    }

    // Update is called once per frame
    void Update()
    {
        enemyList = GameObject.FindGameObjectsWithTag("Enemy");

        print("total enemies=" + enemyList.Length);


        if (enemyRange == true)
        {
            if (Input.GetMouseButton(0))
            {

            }
        }
    }



    private IEnumerator FOVRoutine()
    {
        WaitForSeconds wait = new WaitForSeconds(0.2f);

        while (true)
        {
            yield return wait;
            FieldOfViewCheck();
        }
    }

    private void FieldOfViewCheck()
    {
        Collider[] rangeChecks = Physics.OverlapSphere(transform.position, radius, targetMask);

        if (rangeChecks.Length != 0)
        {
            Transform target = rangeChecks[0].transform;
            Vector3 directionToTarget = (target.position - transform.position).normalized;

            if (Vector3.Angle(transform.forward, directionToTarget) < angle / 2)
            {
                float distanceToTarget = Vector3.Distance(transform.position, target.position);

                if (!Physics.Raycast(transform.position, directionToTarget, distanceToTarget, obstructionMask))
                    enemyRange = true;

                else
                    enemyRange = false;
            }
            else
                enemyRange = false;
        }
        else if (enemyRange)
            enemyRange = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        EnemyScript es;
        if( other.tag == "zombie")
        {
            es = other.gameObject.GetComponent<EnemyScript>();
            es.Zhealth--;
            playerHealth.fistHit = true;
        }
    }
}
