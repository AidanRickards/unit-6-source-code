using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    Animator anim;
    float velocity = 2.5f;
    int backvelocity = 1;
    public int rotationspeed = 10;
    public bool fistHit = false;
    public int Health = 5;
    
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void Update()
    {
        
        fistHit = false;
        anim.SetBool("Damage", false);
        anim.SetBool("Right", false);
        anim.SetBool("Left", false);
        anim.SetBool("Reverse", false);
        anim.SetBool("Jump", false);
        anim.SetBool("Walk", false);
        anim.SetBool("Punch", false);
        if (Input.GetKey(KeyCode.Space))
        {
            anim.SetBool("Z damage", true);
        }

        //walk forward
        if (Input.GetKey("w") == true)
        {
            anim.SetBool("Walk", true);
            transform.position += transform.forward * velocity * Time.deltaTime;
        }

        //walk backward
        if (Input.GetKey("s") == true)
        {
            anim.SetBool("Reverse", true);
            transform.position -= transform.forward * backvelocity * Time.deltaTime;
        }

        //rotate left
        if (Input.GetKey("a") == true)
        {
            anim.SetBool("Left", true);
            transform.Rotate(rotationspeed * Vector3.down * Time.deltaTime);
        }

        //rotate right
        if (Input.GetKey("d") == true)
        {
            anim.SetBool("Right", true);
            transform.Rotate(rotationspeed * Vector3.up * Time.deltaTime);
        }

        //attack
        if(Input.GetMouseButtonDown(0))
        {
            anim.SetBool("Punch", true);
        }

    }


    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.tag == "Enemy")
        {
            if (fistHit == false)
            {
                Health--;
                anim.SetBool("Damage", true);
                if (Health == 0)
                {
                    Destroy(this.gameObject);
                }
            }
        }
    }
}
