using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieDie : MonoBehaviour
{
    Vector3 Pos;
    Vector3 Pos2;
    public GameObject multiSpawn;

    public void testFunction()
    {
        Pos = new Vector3(104, 5, 76);
        Pos2 = new Vector3(109, 5, 76);
        Destroy(this.gameObject);
        var spawnTemp = Instantiate(multiSpawn, Pos, Quaternion.Euler(0, 232, 0));
        var spawnTemp2 = Instantiate(multiSpawn, Pos2, Quaternion.Euler(0, 232, 0));
        //Instantiate(multiSpawn, Pos, Quaternion.identity);
    }


}
